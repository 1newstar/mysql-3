show databases;
shutdown;
