#! /bin/sh
FFN="DBNAME"
if [[ ${FFN} == "DBNAME" ]];then
for i in {1..10}
do
    if [[ $i == 1 || $i == 8 ]];then
        echo "Today is Monday $i"
    else
        echo "$i"
    fi
done
else 
    echo "哈哈"
fi
