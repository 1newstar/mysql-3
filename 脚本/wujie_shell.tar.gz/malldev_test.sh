#! /bin/sh
#  Gitlab 1.0 dev branch local test!
#  Author by Jeff@wujie
#  Version 1.0 
#  Time 2017.01.11

code_path=/web/devtest/wujielive/
if [[ ! -d ${code_path} ]];then
    exit

else
    cd ${code_path}
    git pull
    if [[ `git branch|grep "* dev"|wc -l` == 0 ]];then
	git checkout dev
	git pull
    else
	git pull
    fi

fi
