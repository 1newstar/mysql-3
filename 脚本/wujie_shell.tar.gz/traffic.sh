#! /bin/sh
#	traffic for web by larry 2016.11.18

date=$(date +"%Y%m%d" -d "-1 days")
cd /applogs/real/nginx/
file=`ls|grep ${date}`
echo "####	$(date +"%F" -d "-1 days") 	#"
awk -F " " 'BEGIN{size=0;}{size=size+$10;}END {print "The totall traffic sizes is:",size/1024/1024 "M"}' ${file}
echo "The Totall Dedicated IP :$(awk -F " " '{print $1}' ${file}|sort -u |wc -l)"

