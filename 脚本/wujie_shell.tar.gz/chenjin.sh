#! /bin/sh
*/1 * * * *            curl http://mallt.wujieshenghuo.com/mobile/index.php?act=auto_confirm
