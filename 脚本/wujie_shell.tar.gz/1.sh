#! /bin/sh
# Gitlab hooks for wujie
# 2017.01.12 by Jeff
# version 1.0

sour1b=/web/1/      #1.0 bug source path
sour1d=/web/1/      #1.0 dev source path
sour1m=/web/1/      #1.0 master source path
dest1d=/web/1d/      #1.0 dev dest path
dest1b=/web/1b/      #1.0 bug source path
dest1m=/web/wujielive/
sour2b=/web/gitlab/wujie2.0/
sour2d=/web/gitlab/wujie2.0/
sour2m=/web/gitlab/wujie2.0/
dest2d=/web/wujie2.0dev/
dest2b=/web/wujie2.0bug/
dest2m=/web/wujie2.0/
Date=`date +%F-%H-%M`
Ftime=`date +%F`
miao=`date +%s`
version=$2
bran=$3
name=$1
echo "${version},${bran},${name}" >>/web/hookslog/test.log
if [[ ${version} == "1" ]];then
    case ${bran} in
    "dev")
    cd ${sour1d}
    mkdir ${miao}
    echo "${miao}">${miao}.txt
    if [[ $? == 0 ]];then
       # git checkout dev:dev
        if [[ 1 == 1 ]];then
       # git pull origin dev
            if [[ $? == 0 ]];then
            rsync -avzP --exclude-from=/web/exclude.list ${sour1d} ${dest1d} >/web/hookslog/zhongji.log
                if [[ $? == 0 ]];then
                    echo "####  ${Date} ###    ${name}   ###    ${bran}" >>/web/hookslog/rsync.log
                    egrep ".html|.php|.htm|.txt" /web/hookslog/zhongji.log>>/web/hookslog/rsync.log
                else
                    echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###  Rsync  \033[31m ${bran}\033[0m Failed!"
                fi
            else
                echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git pull  \033[31m ${bran}\033[0m Failed!"
            fi
        else
            echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git checkout  \033[31m ${bran}\033[0m Failed!"
        fi
    fi
    ;;
    *)
    echo "other" >>/web/hookslog/rsync.log
    ;;
    esac
fi
