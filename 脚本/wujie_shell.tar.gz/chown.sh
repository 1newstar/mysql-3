#! /bin/sh
read -p "Input web dir:" Webdir
cd $Webdir
array_dir=(temp/ data/files/ data/ data/files/mall/template/ mobile/static/combine/)
i=0   
chown nginx ${array_dir[i]} -R
if [[ $? == 0 ]];then
    echo "${array_dir[i]} changing has  finished"
    else
    echo "${array_dir[i]} changed failure."
fi
i=1   
chown nginx ${Webdir}/${array_dir[i]} -R
if [[ $? == 0 ]];then
    echo "${array_dir[i]} changing has  finished"
    else
    echo "${array_dir[i]} changed failure."
fi
i=2   
find ${Webdir}/${array_dir[i]} -name "*.php" -type f |xargs chown nginx.webftp
find ${Webdir}/${array_dir[i]} -name "*.php" -type f |xargs chmod 664
find ${Webdir}/${array_dir[i]} -name "*.lock" -type f |xargs chown nginx
find ${Webdir}/${array_dir[i]} -name "generate.txt" -type f |xargs chown nginx.webftp
if [[ $? == 0 ]];then
    echo "${array_dir[i]} changing has  finished"
    else
    echo "${array_dir[i]} changed failure."
fi
i=3   
chown nginx.webftp ${Webdir}/${array_dir[i]} -R
if [[ $? == 0 ]];then
    echo "${array_dir[i]} changing has  finished"
    else
    echo "${array_dir[i]} changed failure."
fi
i=4   
chown nginx ${Webdir}/${array_dir[i]} -R
if [[ $? == 0 ]];then
    echo "${array_dir[i]} changing has  finished"
    else
    echo "${array_dir[i]} changed failure."
fi


