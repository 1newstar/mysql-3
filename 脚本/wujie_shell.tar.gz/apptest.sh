#! /bin/sh
# push git to 68
# Add by Jeff @wujieshenghuo 20170103

# mall_path=/web/git/wujielive/
app_path=/web/devtest/wujie2.0/
#rsync -avzP --exclude-from=/web/gitlab/exclude.list --password-file=/etc/password.s ${app_path} web@120.76.247.68::apit
rsync -avzP --exclude-from=/web/gitlab/exclude.list --password-file=/etc/password.s ${app_path} web@120.76.247.68::apit
