#! /bin/sh
#  Gitlab for APP2.0 dev branch local test!
#  Author by Jeff@wujie
#  Version 1.0 
#  Time 2017.01.11

code_path=/web/devtest/wujie2.0/
if [[ ! -d ${code_path} ]];then
    exit

else
    cd ${code_path}
    if [[ `git branch|grep "* 2.0dev"|wc -l` == 0 ]];then
	git checkout 2.0dev
	git pull
    else
	git pull
    fi

fi
