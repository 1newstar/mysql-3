#! /bin/sh

#	change virtual ip
ifup eth0:1
ifdown eth0:1
ifup eth0:1
