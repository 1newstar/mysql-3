#! /bin/sh
# Gitlab hooks for wujie
# 2017.01.13 by Jeff
# version 1.0

sour1b=/web/1/wujielivebug/      #1.0 bug source path
sour1d=/web/1/wujielivedev/      #1.0 dev source path
sour1m=/web/1/wujielive/      #1.0 master source path
dest1d=/web/wujielivedev/      #1.0 dev dest path
dest1b=/web/wujielivebug/      #1.0 bug source path
dest1m=/web/wujielive/
sour2b=/web/1/wujie2.0bug/
sour2d=/web/1/wujie2.0dev/
sour2m=/web/1/wujie2.0/
dest2d=/web/wujie2.0dev/
dest2b=/web/wujie2.0bug/
dest2m=/web/wujie2.0/
#   www config
sour3m=/web/1/www/       #www git dir   
dest3m=/web/newwww/         #www web root dir
#   new version for wujie config
sour8m=//web/1/new_wujie/
dest8m=/web/new_wujie/
sour8d=/web/1/new_wujiedev/
dest8d=/web/new_wujiedev/
Date=`date +%F-%H-%M`
filedate=`date +%F`
name=$1
version=$2
bran=$3
if [ $# -ne 3 ];then
echo -e "\033[32mUsage:\033[0m  \033[31m *****.sh [name] [version] [branch]\033[0m"
else
if [[ ${version} == "1" ]];then
    case ${bran} in
    "dev")
    cd ${sour1d}
    if [[ $? == 0 ]];then
        git checkout dev
        if [[ `git branch|grep "* dev"|wc -l` == 1 ]];then
        git pull origin dev:dev
            if [[ $? == 0 ]];then
            rsync -avzP --exclude-from=/web/exclude.list ${sour1d} ${dest1d} >/web/hookslog/zhongji.log
                if [[ $? == 0 ]];then
                    echo "####  ${Date} ###    ${name}   #  ${version}  #    ${bran}" >>/web/hookslog/${filedate}.log
                    egrep ".html|.php|.htm|.txt|.js|.css|.jpg|.png" /web/hookslog/zhongji.log>>/web/hookslog/${filedate}.log
                    echo -e "\033[32m git pull V1.0 ${bran} branch and publish for testing has done...\033[0m"
                else
                    echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###  Rsync  \033[31m ${bran}\033[0m Failed!"
                fi
            else
                echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git pull  \033[31m ${bran}\033[0m Failed!"
            fi
        else
            echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git checkout  \033[31m ${bran}\033[0m Failed!"
        fi
    fi
    ;;
    "bug")        
    cd ${sour1b}
    if [[ $? == 0 ]];then
        git checkout bug
        if [[ `git branch|grep "* bug"|wc -l` == 1 ]];then
        git pull origin bug:bug
            if [[ $? == 0 ]];then
            rsync -avzP --exclude-from=/web/exclude.list ${sour1b} ${dest1b} >/web/hookslog/zhongji.log
                if [[ $? == 0 ]];then
                    echo "####  ${Date} ###    ${name}   #  ${version}  #    ${bran}" >>/web/hookslog/${filedate}.log
                    egrep ".html|.php|.htm|.txt|.js|.css|.jpg|.png" /web/hookslog/zhongji.log>>/web/hookslog/${filedate}.log
                    echo -e "\033[32m git pull V1.0 ${bran} branch and publish for testing has done...\033[0m"
                else
                    echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###  Rsync  \033[31m ${bran}\033[0m Failed!"
                    exit 1
                fi
            else
                echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git pull  \033[31m ${bran}\033[0m Failed!"
                exit 1
            fi
        else
            echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git checkout  \033[31m ${bran}\033[0m Failed!"
            exit 1
        fi
    fi
    ;;
    "master")
    cd ${sour1m}
    if [[ $? == 0 ]];then
        git checkout master
        if [[ `git branch|grep "* master"|wc -l` == 1 ]];then
        git pull origin master:master
            if [[ $? == 0 ]];then
            rsync -avzP --exclude-from=/web/exclude.list ${sour1m} ${dest1m} >/web/hookslog/zhongji.log
                if [[ $? == 0 ]];then
                    echo "####  ${Date} ###    ${name}   #  ${version}  #    ${bran}" >>/web/hookslog/${filedate}.log
                    egrep ".html|.php|.htm|.txt|.js|.css|.jpg|.png" /web/hookslog/zhongji.log>>/web/hookslog/${filedate}.log
                    echo -e "\033[32m git pull V1.0 ${bran} branch and publish for testing has done...\033[0m"
                else
                    echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###  Rsync  \033[31m ${bran}\033[0m Failed!"
                    exit 1
                fi
            else
                echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git pull  \033[31m ${bran}\033[0m Failed!"
                exit 1
            fi
        else
            echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git checkout  \033[31m ${bran}\033[0m Failed!"
            exit 1
        fi
    fi
    ;;
    *)
        echo -e "\033[31m Argrument Wrong!\033[0m    ###Useage:\033[32m sh {who|version|branch}\033[0m"
        exit 1
    ;;

    esac
elif [[ ${version} == "2" ]];then
    case ${bran} in
    "dev")
    cd ${sour2d}
    if [[ $? == 0 ]];then
        git checkout 2.0dev
        if [[ `git branch|grep "* 2.0dev"|wc -l` == 1 ]];then
        git pull origin 2.0dev:2.0dev
            if [[ $? == 0 ]];then
            rsync -avzP --exclude-from=/web/exclude.list ${sour2d} ${dest2d} >/web/hookslog/zhongji.log
                if [[ $? == 0 ]];then
                    echo "####  ${Date} ###    ${name}   #  ${version}  #    ${bran}" >>/web/hookslog/${filedate}.log
                    egrep ".html|.php|.htm|.txt|.js|.css|.jpg|.png" /web/hookslog/zhongji.log>>/web/hookslog/${filedate}.log
                    echo -e "\033[32m git pull V2.0 ${bran} branch and publish for testing has done...\033[0m"
                else
                    echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###  Rsync  \033[31m ${bran}\033[0m Failed!"
                    exit 1
                fi
            else
                echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git pull  \033[31m ${bran}\033[0m Failed!"
                exit 1
            fi
        else
            echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git checkout  \033[31m ${bran}\033[0m Failed!"

            exit 1
        fi
    fi
    ;;
    "bug")        
    cd ${sour2b}
    if [[ $? == 0 ]];then
        git checkout bug
        if [[ `git branch|grep "* bug"|wc -l` == 1 ]];then
        git pull origin bug:bug
            if [[ $? == 0 ]];then
            rsync -avzP --exclude-from=/web/exclude.list ${sour2b} ${dest2b} >/web/hookslog/zhongji.log
                if [[ $? == 0 ]];then
                    echo "####  ${Date} ###    ${name}   #  ${version}  #    ${bran}" >>/web/hookslog/${filedate}.log
                    egrep ".html|.php|.htm|.txt|.js|.css|.jpg|.png" /web/hookslog/zhongji.log>>/web/hookslog/${filedate}.log
                    echo -e "\033[32m git pull V2.0 ${bran} branch and publish for testing has done...\033[0m"
                else
                    echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###  Rsync  \033[31m ${bran}\033[0m Failed!"
                    exit 1
                fi
            else
                echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git pull  \033[31m ${bran}\033[0m Failed!"
                exit 1
            fi
        else
            echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git checkout  \033[31m ${bran}\033[0m Failed!"
            exit 1
        fi
    fi
    ;;
    "master")
    cd ${sour2m}
    if [[ $? == 0 ]];then
        git checkout master
        if [[ `git branch|grep "* master"|wc -l` == 1 ]];then
        git pull origin master:master
            if [[ $? == 0 ]];then
            rsync -avzP --exclude-from=/web/exclude.list ${sour2m} ${dest2m} >/web/hookslog/zhongji.log
                if [[ $? == 0 ]];then
                    echo "####  ${Date} ###    ${name}   #  ${version}  #    ${bran}" >>/web/hookslog/${filedate}.log
                    egrep ".html|.php|.htm|.txt|.js|.css|.jpg|.png" /web/hookslog/zhongji.log>>/web/hookslog/${filedate}.log
                    echo -e "\033[32m git pull V2.0 ${bran} branch and publish for testing has done...\033[0m"
                else
                    echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###  Rsync  \033[31m ${bran}\033[0m Failed!"
                    exit 1
                fi
            else
                echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git pull  \033[31m ${bran}\033[0m Failed!"
                exit 1
            fi
        else
            echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git checkout  \033[31m ${bran}\033[0m Failed!"
            exit 1
        fi
    fi
    ;;
    *)
        echo -e "\033[31m Argrument Wrong!\033[0m    ###Useage:\033[32m sh {who|version|branch}\033[0m"
        exit 1
    ;;
    esac
elif [[ ${version} == "www" ]];then
    cd ${sour3m}
    if [[ $? == 0 ]];then
        git checkout master
        if [[ `git branch|grep "* master"|wc -l` == 1 ]];then
        git pull origin master:master
            if [[ $? == 0 ]];then
            rsync -avzP --exclude-from=/web/exclude.list ${sour3m} ${dest3m} >/web/hookslog/zhongji.log
                if [[ $? == 0 ]];then
                    echo "####  ${Date} ###    ${name}   #  ${version}  #    ${bran}" >>/web/hookslog/${filedate}.log
                    egrep ".html|.php|.htm|.txt|.js|.css|.jpg|.png" /web/hookslog/zhongji.log>>/web/hookslog/${filedate}.log
                    echo -e "\033[32m git pull www ${bran} branch and publish for testing has done...\033[0m"
                else
                    echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###  Rsync  \033[31m ${bran}\033[0m Failed!"
                    exit 1
                fi
            else
                echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git pull  \033[31m ${bran}\033[0m Failed!"
                exit 1
            fi
        else
            echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git checkout  \033[31m ${bran}\033[0m Failed!"

            exit 1
        fi
    fi
#    new_wujie shell
elif [[ ${version} == "8" ]];then
    case ${bran} in
    "dev")
    cd ${sour8d}
    if [[ $? == 0 ]];then
        git checkout dev
        if [[ `git branch|grep "* dev"|wc -l` == 1 ]];then
        git pull origin dev:dev
            if [[ $? == 0 ]];then
            rsync -avzP --exclude-from=/web/new_exclude.list ${sour8d} ${dest8d} >/web/hookslog/zhongji.log
                if [[ $? == 0 ]];then
                    echo "####  ${Date} ###    ${name}   #  ${version}  #    ${bran}" >>/web/hookslog/${filedate}.log
                    egrep ".html|.php|.htm|.txt|.js|.css|.jpg|.png" /web/hookslog/zhongji.log>>/web/hookslog/${filedate}.log
                    echo -e "\033[32m git pull New_wujie ${bran} branch and publish for testing has done...\033[0m"
                else
                    echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###  Rsync  \033[31m ${bran}\033[0m Failed!"
                    exit 1
                fi
            else
                echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git pull  \033[31m ${bran}\033[0m Failed!"
                exit 1
            fi
        else
            echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git checkout  \033[31m ${bran}\033[0m Failed!"

            exit 1
        fi
    fi
    ;;
    "master")        
    cd ${sour8m}
    if [[ $? == 0 ]];then
        git checkout master
        if [[ `git branch|grep "* master"|wc -l` == 1 ]];then
        git pull origin master:master
            if [[ $? == 0 ]];then
            rsync -avzP --exclude-from=/web/new_exclude.list ${sour8m} ${dest8m} >/web/hookslog/zhongji.log
                if [[ $? == 0 ]];then
                    echo "####  ${Date} ###    ${name}   #  ${version}  #    ${bran}" >>/web/hookslog/${filedate}.log
                    egrep ".html|.php|.htm|.txt|.js|.css|.jpg|.png" /web/hookslog/zhongji.log>>/web/hookslog/${filedate}.log
                    echo -e "\033[32m git pull new_wujie ${bran} branch and publish for testing has done...\033[0m"
                else
                    echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###  Rsync  \033[31m ${bran}\033[0m Failed!"
                    exit 1
                fi
            else
                echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git pull  \033[31m ${bran}\033[0m Failed!"
                exit 1
            fi
        else
            echo -e "####  ${Date} ###    \033[32m${name}\033[0m   ###   git checkout  \033[31m ${bran}\033[0m Failed!"
            exit 1
        fi
    fi
    ;;
    esac
fi
fi
