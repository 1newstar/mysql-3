#!/bin/bash
#######Nginx Log Rote######By Larry  2016.10.18#########
###Set log path###
logs_path="/usr/local/php/logs/"
new_logs_path="/applogs/test/php/"
###Set Nginx Pid file###########
pid_path="/usr/local/php/logs/php-fpm.pid"
#### Rename the logs file#########
mv ${logs_path}php-fpm.log ${new_logs_path}php-fpm_$(date -d "yesterday" +"%Y%m%d").log
#       change log file         ####
kill -USR1 `cat ${pid_path}`
###	change logs mod for ftp user can download	####
chmod o+r ${new_logs_path}php-fpm_$(date -d "yesterday" +"%Y%m%d").log
