#!/bin/bash
#######Nginx Log Rote######By Larry  2016.10.18#########
###Set log path###
logs_path="/usr/local/nginx/logs/"
###Set Nginx Pid file###########
pid_path="/usr/local/nginx/logs/nginx.pid"
###	new logs path for ftp dir 	###
new_logs_path="/applogs/test/nginx/"
#### Rename the logs file#########
mv ${logs_path}mall-access.log ${new_logs_path}mall-access_$(date -d "yesterday" +"%Y%m%d").log
mv ${logs_path}www-access.log ${new_logs_path}www-access_$(date -d "yesterday" +"%Y%m%d").log
cp ${logs_path}error.log ${new_logs_path}error_$(date -d "yesterday" +"%Y%m%d").log
#	change log file		####
kill -USR1 `cat ${pid_path}`
##	change log mod for FTPuser download		####
chmod o+r ${new_logs_path}mall-access_$(date -d "yesterday" +"%Y%m%d").log
chmod o+r ${new_logs_path}www-access_$(date -d "yesterday" +"%Y%m%d").log
chmod o+r ${new_logs_path}error_$(date -d "yesterday" +"%Y%m%d").log
cd ${new_logs_path}
awk -F "\"" '{print $2}' error_$(date -d "yesterday" +"%Y%m%d").log >1.txt
sleep 3
cat 1.txt >error_$(date -d "yesterday" +"%Y%m%d").log
rm 1.txt -f
