#! /bin/sh
# push git to 68
# Add by Jeff @wujieshenghuo 20170103

app_path=/web/wujie2.0/
name=$1
versions=$2
Date=`date +%F-%H-%M`
if [[ $# -ne 2 ]];then
    echo -e "\033[32mUsage:\033[0m  \033[31m *****.sh [name] [version]\033[0m"
else
    rsync -avzP --files-from=/web/include.list --password-file=/etc/password.s ${app_path} web@120.76.247.68::app >/web/hookslog/zhongji.log
    if [[ $? == 0 ]];then
        echo "####  ${Date} ###    ${name}   #  ${versions}  " >>/web/hookslog/pub.log
        egrep ".html|.php|.htm|.txt|.js|.css|.jpg|.png" /web/hookslog/zhongji.log >>/web/hookslog/pub.log
    else
        echo "Rsync failure!"
    fi
fi
