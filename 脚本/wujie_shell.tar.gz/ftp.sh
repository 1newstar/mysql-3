#!/bin/sh
# For add ftpuser by larry 20161109 version 01	#
FtpConfDir=/etc/vsftpd
FtpUserDir=${FtpConfDir}/vconf
echo -e "\n    1:logs group --this group user only have privileges to down the logs.\n    2:web group --this group user only have the privileges to update all the web files and contents.\n    3:file groups  --this group user only have the privileges to up or download the file.\n    4:delete ftp user.\n"
read -p "Please choice which group you want to add:" choice
case ${choice} in
 1)
    read -p "Please input username:" username
    while [[ ${username} != logs_* ]]
       do
       echo "Name format:logs_YOURNAME"
       read -p "The input name must Begin with logs_:" username
    done
    read -p "Please input your password:" password
    echo -e "${username}\n${password}" >>${FtpConfDir}/virtusers
    db_load -T -t hash -f /etc/vsftpd/virtusers /etc/vsftpd/virtusers.db
    /bin/cp $FtpUserDir/logs.default $FtpUserDir/${username}
    read -p "Please input the user's root dir:" dir
    echo "local_root=${dir}" >>$FtpUserDir/${username}
    echo -e "user add successed!Please record them:\nusername:${username}\npassword:${password}"
    sleep 1
    echo "Now restart the vsftpd service:"
    service vsftpd restart
    ;;
 2)
    read -p "Please input username:" username
    while [[ ${username} != web_* ]]
       do
       echo "Name format:web_YOURNAME"
       read -p "The input name must Begin with web_:" username
       done
    read -p "Please input your password:" password
    echo -e "${username}\n${password}" >>${FtpConfDir}/virtusers
    db_load -T -t hash -f /etc/vsftpd/virtusers /etc/vsftpd/virtusers.db
    /bin/cp $FtpUserDir/web.default $FtpUserDir/${username}
    read -p "Please input the user's root dir:" dir
    echo "local_root=${dir}" >>$FtpUserDir/${username}
    echo -e "user add successed!Please record them:\nusername:${username}\npassword:${password}"
    sleep 1
    echo "Now restart the vsftpd service:"
    service vsftpd restart
    ;;
 3)
    read -p "Please input username:" username
    read -p "Please input your password:" password
    echo -e "${username}\n${password}" >>${FtpConfDir}/virtusers
    db_load -T -t hash -f /etc/vsftpd/virtusers /etc/vsftpd/virtusers.db
    /bin/cp $FtpUserDir/ftp.default $FtpUserDir/${username}
    read -p "Please input the user's root dir:" dir
    echo "local_root=${dir}" >>$FtpUserDir/${username}
    echo -e "user add successed!Please record them:\nusername:${username}\npassword:${password}"
    sleep 1
    echo "Now restart the vsftpd service:"
    service vsftpd restart
    ;;
 4)
    read -p "Please input username which you want to delete:" delusername
 
    while [[ `grep ${delusername} ${FtpConfDir}/virtusers |wc -l` -ne 1 ]]
    do   
       echo "There is no user named ${delusername}"
       read -p "Please input again:" delusername
    done    
    sed -i "/${delusername}/,+1d" ${FtpConfDir}/virtusers
    rm -f /etc/vsftpd/virtusers.db
    db_load -T -t hash -f /etc/vsftpd/virtusers /etc/vsftpd/virtusers.db
    /bin/rm ${FtpUserDir}/${delusername} -f
    sleep 1
    echo "The user has been deleted!"
    echo "Now restart the vsftpd service:"
    service vsftpd restart
    ;;
esac


