#! /bin/sh
#  gitlab backup shell by Jeff @wujie 2017.01.13
bpath=/backup/git_back/

gitlab-rake gitlab:backup:create

find ${bpath} -mtime +5 -exec rm -fr {} \;
