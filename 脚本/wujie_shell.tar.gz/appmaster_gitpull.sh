#! /bin/sh
#  Gitlab for APP2.0 master branch local test!
#  Author by Jeff@wujie
#  Version 1.0 
#  Time 2017.01.11

master_path=/web/gitlab/wujie2.0/

cd ${master_path}
if [[ `git branch|grep "* master"|wc -l` == 0 ]];then
    git checkout master
    git pull
else
    git pull
fi

